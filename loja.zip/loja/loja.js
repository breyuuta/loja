/*  Oi professor!
        Como não foi especificado quanto ao tipo de itens, decidi 
        "brincar" um pouco e fazer uma loja com itens de um jogo...
        Apesar dessa escolha talvez fazer parecer que não foi tão
        sério, creio que o conteúdo abordado foi atendido independentemente
        da natureza dos itens. Abraço!   */